<? php
// silence is golden